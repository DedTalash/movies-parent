package telran.movies.dto;

public interface MovieCinemaTickets {
String getMovie();
String getCinema();
Long getTickets();
}
