package telran.movies.dto;

public class WatchDto {
public String movieName;
public String cinemaName;
public String dateTime;
public int ticketCost;
public int tickets;
}
