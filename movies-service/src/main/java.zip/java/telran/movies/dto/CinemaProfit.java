package telran.movies.dto;

public interface CinemaProfit {
long getProfit();
String getCinema();
}
