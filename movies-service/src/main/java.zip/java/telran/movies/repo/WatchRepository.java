package telran.movies.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import telran.movies.entities.Watch;

import java.util.List;

public interface WatchRepository extends JpaRepository<Watch, Long> {

    List<Watch> findByMovieName(String name); // Spring build this method by its name
}
