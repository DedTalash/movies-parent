package telran.movies.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Entity
@Table(name = "movies")
public class Movie {
    @Id
    String name;

//    public List<Watch> getWatches() {
//        return watches;
//    }

    public void setProducer(String producer) {
        this.producer = producer;
    }

    String producer;
    int year;
    @OneToMany(mappedBy = "movie")
    List<Watch> watches;

    public Movie() {

    }

    public Movie(String name, String producer, int year) {
        super();
        this.name = name;
        this.producer = producer;
        this.year = year;
    }

    @Override
    public String toString() {
        return "Movie [name=" + name + ", producer=" + producer + ", year=" + year + "]";
    }

    public String getName() {
        return name;
    }

    public String getProducer() {
        return producer;
    }

    public int getYear() {
        return year;
    }


}
